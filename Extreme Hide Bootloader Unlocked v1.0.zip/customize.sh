SKIPUNZIP=1

if [ "$APATCH" ]; then
  ui_print "APatch version: $APATCH_VER ($APATCH_VER_CODE)"
else
  abort "! This module is only for APatch!"
fi

unzip -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >&2

set_perm_recursive "$MODPATH" 0 0 0755 0644